# 지표 홍보 웹페이지 업로드 안내

GitHub에는 아래 구조 그대로 올리면 됩니다.

- index.html
- images/jipyo_logo.png
- images/jipyo_class_discussion.png
- videos/jipyo_60s_brand.mp4  ← 민경이가 만든 60초 영상 파일명
- videos/jipyo_deepdive_30min.mp4  ← NotebookLM 30분 설명 영상 파일명

주의:
HTML 안에 이미지를 base64로 직접 넣으면 파일이 너무 커지고,
브라우저에서 코드처럼 보이거나 GitHub에서 미리보기가 깨질 수 있습니다.
이미지는 images 폴더에 따로 넣고, HTML에서는 상대경로로 불러오는 방식이 안전합니다.
